﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PurchaseLog : MonoBehaviour
{ 
    [SerializeField]
   public GameObject AutoCookie;
    public GameObject autosell;
    public AudioSource PlaySound;


    public void StartAutoCookie() // A function but is hidden from the inspector with contrast
    {
        PlaySound.Play();
        AutoCookie.SetActive(true);
        GlobalCash.CashCount -= GlobalBaker.bakerValue;
        GlobalBaker.bakerValue *= 2;
        GlobalBaker.turnOffButton = true; // Set the button to be non interactable

        GlobalBaker.numberofBaker += 1;
        GlobalBaker.bakePersec += 1;
    }

    public void StartAutoSell() // A function but is hidden from the inspector with contrast
    {
        PlaySound.Play();
        autosell.SetActive(true);
        GlobalCash.CashCount -= GlobalShop.shopValue;
        GlobalShop.shopValue *= 2;
        GlobalShop.turnOffButton = true; // Set the button to be non interactable

        GlobalShop.shopPerSec += 1;
        GlobalShop.numberOfShops += 1;
    }
}
