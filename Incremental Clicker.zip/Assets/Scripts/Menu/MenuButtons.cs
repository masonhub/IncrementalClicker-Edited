﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace jase
{
    public class MenuButtons : MonoBehaviour
    {
        public int LoadedScore;
        public static int saveValue =10; 
     //   private Text Highscore;
     //   private Text score;

        public void ChangeScene(int sceneIndex)
        {
            SceneManager.LoadScene(sceneIndex);
        }

        public void Newgame()
        {
            GlobalCash.CashCount -= 0;
            PlayerPrefs.DeleteKey(GlobalCookies.CookieCount.ToString());
            PlayerPrefs.DeleteKey(GlobalCash.CashCount.ToString());
            PlayerPrefs.DeleteKey(GlobalBaker.bakePersec.ToString());
            PlayerPrefs.DeleteKey(GlobalShop.numberOfShops.ToString());
            saveValue *= 2;
            PlayerPrefs.SetInt("SaveValue", saveValue);
            SceneManager.LoadScene(0);
        }
        public void QuitGame()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#endif
            Application.Quit();
        }


        public void LoadFile()
        {
            string filePath = Application.dataPath + "/SaveFile.SAV";
            Debug.Log(filePath);
            FileStream file;

            if (File.Exists(filePath))
            {
                file = File.OpenRead(filePath);
            }
            else
            {
                Debug.LogError("Save file not found");
                return;
            }

            BinaryFormatter bf = new BinaryFormatter();
        //    GameData data = (GameData)bf.Deserialize(file);
            file.Close();

        //    LoadedScore = data.Score;

        }
    }
}