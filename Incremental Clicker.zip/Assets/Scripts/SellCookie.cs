﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class SellCookie : MonoBehaviour
{

    public GameObject statusBox;
   // public GameObject textbox;
    public AudioSource cashOne;
    public AudioSource cashtwo;
    public AudioSource noCookie;
    public int generateTone;


    
    public void Sell()
    {
        generateTone = Random.Range(1, 3);
        if (GlobalCookies.CookieCount == 0)
        {
           statusBox.GetComponent<Text>().text = "No Enough cookies to sell text"; // Dislay the string 
           statusBox.SetActive(true);
            //statusBox.GetComponent<Animator>().Play("StatusAnimation"); // Create an animation for the text 
          
        }
        else
        {
            if(generateTone == 1)
            {
                cashOne.Play();
            }
            if(generateTone == 2)
            {
                cashtwo.Play();
            }
        GlobalCash.CashCount += 1;
        GlobalCookies.CookieCount -= 1;
            
        }
    }
    // Set statusbox to false 
    private void Update()
    {
       if(GlobalCookies.CookieCount > 0)
        {
            statusBox.SetActive(false);
        }
    }

    private void Start()
    {
        statusBox.SetActive(false);
    }
}
